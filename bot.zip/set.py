import os

os.system("apt install wget")
os.system("apt install tightvncserver")
os.system("tightvncserver :1")
os.system("apt -y install screen")
